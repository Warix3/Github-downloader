# Intergrated-Gitzip
An extension to the github.com website. It adds a download functionality for all folders and files.
